# Tubetto Web 1.0.1

Tubetto dal browser del PC (Windows, Mac, Linux), da qualsiasi rete.
Stessa libreria dell'app: preferiti, playlist, artisti, canali e cronologia
passano dal file `sync/tubetto-library.json` del repo privato **Tubetto**.

## Come è fatto
- `site/` → la pagina web, pubblicata gratis con **GitHub Pages** (repo pubblico `tubetto-web`, solo HTML/JS, nessun dato personale).
- `worker/worker.js` → il "ponte" verso le API interne di YouTube, su **Cloudflare Workers** (gratis, 100.000 richieste/giorno).
- Riproduzione con il player ufficiale incorporato di YouTube.

## 1) Cloudflare Worker (una volta sola, ~5 minuti)
1. Crea un account gratuito su https://dash.cloudflare.com
2. **Workers & Pages → Create → Create Worker** → nome `tubetto` → **Deploy**.
3. **Edit code** → cancella tutto, incolla il contenuto di `worker/worker.js` → **Deploy**.
4. **Settings → Variables and Secrets → Add** → tipo *Secret*, nome `TUBETTO_KEY`, valore una parola segreta a tua scelta → **Deploy**.
5. Annota l'indirizzo: `https://tubetto.<tuo-sottodominio>.workers.dev`
   (prova: aprendolo nel browser deve rispondere "Chiave non valida", è giusto).

## 2) GitHub Pages (una volta sola)
1. Crea un repo **pubblico** `tubetto-web`.
2. **Add file → Create new file** → nome `.github/workflows/deploy.yml` → incolla il contenuto di `deploy.yml` → Commit.
3. **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. Carica `tubetto-web-1.0.0.zip` nella root (Add file → Upload files).
   In 1 minuto la pagina è online su `https://mariopinola10.github.io/tubetto-web/`

Aggiornamenti futuri: carica solo il nuovo `tubetto-web-X.Y.Z.zip`, viene pubblicata la versione più alta.

## 3) Primo avvio sul PC
Apri il link → compila:
- Worker: l'indirizzo del punto 1 e la chiave `TUBETTO_KEY`
- Repository: `mariopinola10/Tubetto`
- Token: lo stesso dell'app (fine-grained, solo repo Tubetto, *Contents: Read and write*)

**Prova collegamento** → **Salva**. Il token resta solo nel browser di quel PC.
Suggerimento: in Chrome/Edge menu ⋮ → *Trasmetti, salva e condividi → Installa pagina come app* per averla come programma con icona.

## Scorciatoie
Spazio play/pausa · N successivo · P precedente · L mi piace · / cerca · tasto destro su un brano = menu.

## Limiti
- Alcuni video ufficiali (spesso VEVO) non permettono la riproduzione fuori da YouTube:
  Tubetto Web prova da solo una versione alternativa, altrimenti passa al brano successivo.
- Possono comparire gli annunci del player YouTube: su PC basta uBlock Origin.
- Se YouTube cambia le API interne, si aggiornano le versioni client in cima a `worker.js`.
